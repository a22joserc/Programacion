package pila;

public class A {
	int modificarDeA(int i){
		int j=3;
		return j+i;
	}
}
