package pila;

public class B {
	int modificarDeB(int k){
		 int p=2;
		 int z=0;
		 z= suma1(p);
		 return k+z;
		 }
		 int suma1(int w){
		 return w + 1;
		 }
}
