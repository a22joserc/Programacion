package pila;

public class MainPila {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
		int y=10;
		A a=new A();
		B b =new B();
		x=a.modificarDeA(x);
		y=b.modificarDeB(y);
	}

}
