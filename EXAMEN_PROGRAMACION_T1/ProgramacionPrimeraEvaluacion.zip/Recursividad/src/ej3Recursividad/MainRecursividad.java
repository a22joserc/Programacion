package ej3Recursividad;

public class MainRecursividad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Recursividad re=new Recursividad();
		re.imprimir(5);
	}

}
