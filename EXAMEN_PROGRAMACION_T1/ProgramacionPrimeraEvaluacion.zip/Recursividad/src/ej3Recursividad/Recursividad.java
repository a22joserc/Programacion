package ej3Recursividad;

public class Recursividad {
	public void imprimir(int x) {
		if(x>0){
			imprimir(x-1);
			System.out.println(x);
		}
	}
}
