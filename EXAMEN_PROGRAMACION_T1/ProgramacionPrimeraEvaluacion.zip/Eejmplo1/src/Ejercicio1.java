
public class Ejercicio1 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int edad; //declaramos (definimos) una variable
		edad=60; //le damos un valor a una variable
		int peso=75; //al mismo tiempo que se define una variable se le puede asignar un valor
		System.out.println(edad);
		System.out.println(peso);
		//el valor de la variable se puede imprimir junto a cadenas de caracteres
		System.out.println("mi edad es: " + edad);
		peso=80; // Sobrescribimos la variable
		System.out.println(peso);
		//puedo hacer operaciones con las variables
		System.out.println("el peso de los años ..." + peso*edad);
		//el resultado de una operacion puede almacenarse en otra variable
		int salud;
		salud=peso*edad;
		System.out.println("la variable salud contiene el valor: " + salud);
		//el valor que se le asigna a una variable deber ser compatible con su tipo
		String jamones="jamones para todos";
		System.out.println(jamones);

	}

}
