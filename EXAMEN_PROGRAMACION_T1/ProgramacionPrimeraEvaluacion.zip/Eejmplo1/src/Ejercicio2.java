public class Ejercicio2 {
	
	public static void main(String[] args) {
		System.out.println("Ejercicio 2");
		int edad=60;
		System.out.println("edad: " + edad);
	}

}
