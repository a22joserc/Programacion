package entrada_salida;
import java.time.*;
import java.util.Locale;
import java.util.Scanner;

public class PrintDateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*ZonedDateTime date = ZonedDateTime.now();
		System.out.printf("Hoy es %1$tA, %1$td de %1$tB de %1$tY %n", date);
		System.out.printf("Son las %1$tH:%1$tM:%1$tS [%1$tp] %n", date);
		System.out.printf("En la zona horaria %s [%tz] %n", date.getZone(), date);
		*/
		Scanner sc =new Scanner(System.in);
		sc.useLocale(Locale.US);
		System.out.println("Introduzca su edad: ");
		int edad = sc.nextInt();
		System.out.println("Introduzca su altura: ");
		double altura = sc.nextDouble();
		sc.nextLine(); //Limpiamos el buffer por el problema del nextLine() que salta la linea después de un numero.
		System.out.println("Introduzca su nombre: ");
		String nombre = sc.nextLine();
		sc.close();
		System.out.println("Su nombre es " + nombre);
		System.out.println("Su edad es " + edad);
		System.out.printf("Su altura (m) es %.2f %n", altura);
		
	}
	

}
