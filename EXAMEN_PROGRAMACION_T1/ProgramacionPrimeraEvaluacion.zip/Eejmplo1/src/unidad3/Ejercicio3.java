package unidad3;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int x=2;
		int y=1;
		// int r1=++x*y;
		int r1=x++*y;
		System.out.println("x: " + x + " y: " + y + " resultado " + r1);
		// int r1=(++x)*y;
		// System.out.println("x: " + x + " y: " + y + " resultado " + r1);
		// int r1=++(x*y); Error
		// System.out.println("x: " + x + " y: " + y + " resultado " + r1);
		boolean compara = true==false;
		System.out.println(compara);*/
		//--------------- Operador Ternario
		int x=5;
		int y=10;
		int z=20;
		int resultado=(x>y && x>z)?x:y;
		System.out.println(resultado);
		if(x>y) {
			System.out.println("El mayor es " + x);
		}
		else {
			System.out.println("El mayor es " + y);
		}
		
		
	}

}
