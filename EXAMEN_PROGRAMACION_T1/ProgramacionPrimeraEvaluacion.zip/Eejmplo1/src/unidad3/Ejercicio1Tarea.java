package unidad3;

public class Ejercicio1Tarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N=5;
		double A=4.56;
		char C='a';
		System.out.println("El valor de N es " + N);
		System.out.println("El valor de A es " + A);
		System.out.println("El valor de C es " + C);
		// Operaciones
		System.out.println("El valor de N + A es: " + (N+A));
		System.out.println("La diferencia A - N es: " + (A-N));
		System.out.println("El valor numerico correspondiente a C es: " + (int)C);
	}

}
