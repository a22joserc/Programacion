package unidad3;

public class Ejercicio6Tarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Tabla de la verdad &&");
		System.out.println("falso\t\t&&\t\tfalso\t\t\t=\t\t" + false);
		System.out.println("falso\t\t&&\t\tverdadero\t\t=\t\t" + false);
		System.out.println("verdadero\t&&\t\tfalso\t\t\t=\t\t" + false);
		System.out.println("verdadero\t&&\t\tverdadero\t\t=\t\t" + true);
		System.out.println("Tabla de la verdad ||");
		System.out.println("falso\t\t||\t\tfalso\t\t\t=\t\t" + false);
		System.out.println("falso\t\t||\t\tverdadero\t\t=\t\t" + true);
		System.out.println("verdadero\t||\t\tfalso\t\t\t=\t\t" + true);
		System.out.println("verdadero\t||\t\tverdadero\t\t=\t\t" + true);
	}

}
