package unidad3;

public class EjerciciosOperadoresLogicos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Ejercicio 4
		/*System.out.println("Tabla de la verdad TRUE (AND) TRUE = " + (true&&true));
		System.out.println("Tabla de la verdad TRUE (AND) FASLE = " + (true&&false));
		System.out.println("Tabla de la verdad FALSE (AND) TRUE = " + (false&&true));
		System.out.println("Tabla de la verdad FALSE (AND) FALSE = " + (false&&false));*/
		// Ejercicio 6
		/*int edad=18;
		System.out.println(((edad>=18 && edad<=40) || (edad>60 && edad<70))? "Está en el rango!": "No está en el rango!");
		if((edad>=18 && edad<=40) || (edad>60 && edad<70)){
			System.out.println("La edad introducida SI se encuntre en el rango de 18 a 40 años y 60 a 70 años");
		}
		else{
			System.out.println("La edad introducida NO se encuntre en el rango de 18 a 40 años y 60 a 70 años");
		}
		*/
		// Ejercicio 7
		/*
		int A=5;
		int B=3;
		int C=12;
		System.out.println("El resultado de A>3 es " + (A>3));
		System.out.println("El resultado de B!=C es " + (B!=C));
		System.out.println("El resultado de A*B==3 es " + (A*B==3));
		System.out.println("El resultado de C/B==-4 es " + (C/B==-4));
		System.out.println("El resultado de (A+B==8) && (A-B==2) es " + ((A+B==8) && (A-B==2)));
		System.out.println("El resultado de (A+B == 8) || (A-B == 6) es " + ((A+B == 8) || (A-B == 6)));*/
		/*int r;
		int a=2;
		for(int i=1; i<11; i++) {
			r=a*i;
			System.out.println(r);
		}*/
		
		// Tabla del 4 utilizando binario <<1 --> Multiplica por 2 <<2 --> Multiplica por 4
		System.out.println(1<<2);
		System.out.println(2<<2);
		System.out.println(3<<2);
		System.out.println(4<<2);
		System.out.println(5<<2);
		System.out.println(6<<2);
		System.out.println(7<<2);
		System.out.println(8<<2);
		System.out.println(9<<2);
		System.out.println(10<<2);
		
		
	}

}
