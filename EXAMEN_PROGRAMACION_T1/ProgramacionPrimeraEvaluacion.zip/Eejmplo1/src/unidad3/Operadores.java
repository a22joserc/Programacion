package unidad3;

public class Operadores {
	public static void main(String[] args) {
		
		/*System.out.println("10%1="+ 10%1);
		System.out.println("10%2="+ 10%2);
		System.out.println("10%3="+ 10%3);
		System.out.println("10%4="+ 10%4);
		System.out.println("10%5="+ 10%5);
		System.out.println("10%6="+ 10%6);
		System.out.println("10%7="+ 10%7);
		System.out.println("10%8="+ 10%8);
		System.out.println("10%9="+ 10%9);
		System.out.println("10%10="+ 10%10);
		System.out.println("10%11="+ 10%11);
		int a=10;
		System.out.println("El numero a " + a + " dividido entre cero es " + a/0);*/
		
		/*int result = +1;
		System.out.println(result);
		result=-9;
		System.out.println(result);
		result+=2;
		System.out.println(result);
		result--;
		System.out.println(result);
		result = -result;
		System.out.println(result);
		boolean soyElMejor = false;
		System.out.println(soyElMejor);
		boolean soyUnFracasado=!soyElMejor;
		System.out.println(soyUnFracasado);*/
		
		/*int i = 3;
		i++;//equivalente a ++i
		System.out.println(i);
		++i;//equivalente a i++
		System.out.println(i);
		System.out.println(++i); //NO equivalente a i++
		System.out.println(i++); //NO equivalente a ++i
		System.out.println(i);*/
		
		/*int miNumero=2+5;
		String miString="2"+"5";
		System.out.println(miNumero);
		System.out.println(miString);*/
		
		String miString1=2+"5";
		System.out.println(miString1);
		String miString2="9"+5;
		System.out.println(miString2);
		String miString3= 9 + " salchichones";
		System.out.println(miString3);
		
		System.out.println(2 + "5");
		System.out.println("9" + 5);
		System.out.println(9 + " salchichones");
		System.out.println(4+1+"-"+4+1);

	}
}