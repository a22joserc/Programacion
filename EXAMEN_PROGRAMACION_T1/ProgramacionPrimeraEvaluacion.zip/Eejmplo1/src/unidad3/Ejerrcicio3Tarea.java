package unidad3;

public class Ejerrcicio3Tarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N=1;
		N+=77; // Alternativa N=N+77;
		System.out.println(N);
		N-=3; // Alternativa N=N-3
		System.out.println(N);
		N*=2; // N=N*2
		System.out.println(N);

	}

}
