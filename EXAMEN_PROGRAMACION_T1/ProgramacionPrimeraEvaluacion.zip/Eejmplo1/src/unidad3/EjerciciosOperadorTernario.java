package unidad3;

public class EjerciciosOperadorTernario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=20;
		int y=4;
		// boolean par=(x%2==0)?true:false;
		//System.out.println("El numero " + x + " es par? " + par);
		// System.out.println(x%2==0? x + "es par": x + " es inpar" );
		// boolean multiplo=(x%y==0)?true:false;
		// System.out.println("El numero " + x + " es multiplo del numero " + y + "? " + multiplo);
		// System.out.println(x%y==0? y + " es multiplo de " + x : y + " no es multiplo de " + x);
		// int new_x=(Math.pow(x, 2)>100)?++x:--x;
		// System.out.println(new_x);
		System.out.println(Math.pow(x, 2)>100? "x valia: " + x + " y ahora vale " + ++x: "x valia: " + x + " y ahora vale " + --x);
	}

}
