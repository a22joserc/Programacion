package unidad3;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=3;
		int y;
		//--------------- y=x++*2;
		// y=x*2;
		// x=x+1;
		// -------------  y = ++x*2;
		x = x+1;
		y = x*2;
		
		System.out.println("x: "+ x + " y: " + y);

	}

}
