package unidad3;

public class Ejercicio2Tarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int X=1;
		int Y=2;
		double M=3.2;
		double N=4.7;
		System.out.println("La suma X + Y = " + (X+Y));
		System.out.println("La diferencia X – Y = " + (X-Y));
		System.out.println("El producto X * Y = " + (X*Y));
		System.out.println("El cociente X / Y = " + (X/Y));
		System.out.println("El resto X % Y = " + (X%Y));
		System.out.println("La suma N + M = " + (N+M));
		System.out.println("La diferencia N – M = " + (N-M));
		System.out.println("El producto N * M = " + (N*M));
		System.out.println("El cociente N / M = " + (N/M));
		System.out.println("El resto N % M = " + (N%M));
		System.out.println("La suma X + N = " + (X+N));
		System.out.println("El cociente Y / M = " + (Y/M));
		System.out.println("El resto Y % M = " + (Y%M));
		System.out.println("El doble de la variable X = " + (X*2));
		System.out.println("El doble de la variable Y = " + (Y*2));
		System.out.println("El doble de la variable M = " + (M*2));
		System.out.println("El doble de la variable N = " + (N*2));
		System.out.println("La suma de todas las variables = " + (X+Y+M+N));
		System.out.println("El producto de todas las variables = " + (X*Y*M*N));
	}

}
