package unidad3;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Pruebas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String str="";
		for(int i=0; i<10; i++) {
			str= str + "*";
			System.out.println(str);	
		}*/
		//Scanner sc = new Scanner(System.in);
		// System.out.println("Introduzca el numero del cual queire calcular el factorial");
		//int num=sc.nextInt();
		//sc.close();
		int num =Integer.parseInt(JOptionPane.showInputDialog("Introduzca el numero del cual queire calcular el factorial"));
		int factorial=1;
		for(int j=num; j>0; j--) {
			factorial=factorial*j;
		}
		System.out.println("El factorial de " + num + " es igual a " + factorial);
	}

}
