package unidad3;

public class Ejercicio7Tarea {
	public static void main(String[]args) {
		System.out.print("A \"quoted\" String is\n");
		System.out.print("\'much\' better if you learn\n");
		System.out.print("the rules of \"escape sequences.\"\n");
		System.out.print("Also, \"\" represents an empty String.\n");
		System.out.print("Don't forget: use \\\" instead of \" !\n");
		System.out.print("\'\' is not the same as \"");
	}

}
