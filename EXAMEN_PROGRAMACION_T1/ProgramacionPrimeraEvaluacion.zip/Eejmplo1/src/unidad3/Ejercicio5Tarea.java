package unidad3;

public class Ejercicio5Tarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double peso=71.5;
		double altura=1.67;
		double IMC=peso/Math.pow(altura, 2);
		System.out.println("El valor de su IMC es " + IMC);
		if (IMC<18.5) {
			System.out.println("Delgado");
		}
		else if(IMC>=18.5 && IMC<=24) {
			System.out.println("Normal");
		}
		else if(IMC>25 && IMC<=29) {
			System.out.println("Sobrepeso");
		}
		else {
			System.out.println("Obeso");
		}

	}

}
