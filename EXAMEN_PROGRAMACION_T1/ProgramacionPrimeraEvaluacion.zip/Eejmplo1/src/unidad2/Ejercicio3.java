package unidad2;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int radio=2;
		double area;
		//final float PI = (float) Math.PI;
		area=Math.PI*Math.pow(radio,2);
		// area=PI*Math.pow(radio,2);
		System.out.println("El area del círculo de radio " + radio + "m, es igual a " + area + " m2");*/
		// System.out.println("1/3 con valores float " + 1.0f/3.0f);
		// System.out.println("1/3 con valores double "+ 1.0/3.0);
		/* char letra_n;
		letra_n='n';
		System.out.println("El valor de la variable letra_n es "+letra_n);
		letra_n=110;
		System.out.println("\tEres el puto \'Chu\' \\ Unicode Decimal: El valor de la variable letra_n es " +letra_n + "\n");
		letra_n='\u006E';
		System.out.println("Unicode:El valor de la variable letra_n es "+letra_n);*/
		/*
		System.out.print("A\tB\tC\n");
		System.out.print('A');
		System.out.print('\t');
		System.out.print('B');
		System.out.print('\t');
		System.out.print('C');
		System.out.print('\'');
		String saludo="hola";
		System.out.println(saludo);
		System.out.println(saludo + " mundo" );*/
		boolean b;
		b=false;
		System.out.println(" b es " + b);
		System.out.println("hola mundo");
		b=true;
		System.out.println(" b es " + b);
		

	}

}
