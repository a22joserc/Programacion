package unidad2;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char sexo='H';
		byte edad=49;
		float peso=80.5f;
		String nombre="Jose Victor Ramos Castro";
		System.out.println("Nombre: " + nombre);
		System.out.println("Sexo: " + sexo);
		System.out.println("Edad: " + edad);
		System.out.println("Peso: " + peso);
		

	}

}
