package unidad2;

public class Ejercicio4 {
	public enum sexo {H,M,B};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean casado=true;
		final int VALOR_MAXIMO=999999;
		float totalFactura=82.25f;
		long poblacionMundial=10000000000L;
		System.out.println("Casado: " + casado);
		System.out.println("Sexo: " + sexo.H);
		System.out.println("Valor Máximo: " + VALOR_MAXIMO);
		System.out.println("Total factura: " + totalFactura);
		System.out.println("Población Mundial: " + poblacionMundial);

	}

}
