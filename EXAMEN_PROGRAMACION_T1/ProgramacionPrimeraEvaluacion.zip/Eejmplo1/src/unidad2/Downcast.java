package unidad2;

public class Downcast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long l;
		double d;
		l=22222222L;
		d=l; 
		//hay conversión automática
		/* double d=29.7;
		int i =(int) d;
		System.out.println(i);
		int entero1=10;
		int entero2=300;
		System.out.println((byte)entero1);
		System.out.println((byte)entero2);*/
		
		/* double x, y;
		byte b;
		int i;
		char ch;
		x=10.0;
		y=3.0;

		i =(int) (x/y);
		System.out.println("Salida de entero de x/y: " + i);
		
		i= 300;
		b= (byte) i; //habrá perdida
		System.out.println("al convertir int 300 a byte: " + b);
		
		i= 18600;
		b= (byte) i; //habrá perdida y se genera un número negativa por que el 8º bit codifica signo en el tipo byte.
		System.out.println("al convertir int 18600 a byte: " + b);*/
		
		/*
		char c='c';
	
		// boolean b = (boolean) ch; // Error
		byte b = (byte)c;
		System.out.println(b);
		short s = (short) c;
		System.out.println(s);
		int i = c; 
		System.out.println(i);
		long l = c; 
		System.out.println(l);
		float f = c; 
		System.out.println(f);
		double d = c;
		System.out.println(d);*/
		// ----------------------------- Ejercicio 2 --------------------------//
		/*char A='b';
		int i1 = (int) A;
		System.out.println(i1);*/
		// ----------------------------- Ejercicio 3 --------------------------//
		/*System.out.println("Código entero del caracter \'A\': " + (int)'A');
		System.out.println("Código entero del caracter \'B\': " + (int)'B');
		System.out.println("Código entero del caracter \'B\': " + ('A'+1));
		System.out.println("Código entero del caracter \'B\': " + (char)('A'+1));*/
		// ----------------------------- Ejercicio 4 --------------------------//
		 int i=62300;
		// byte b= (byte) i;
		//char c= (char) i;
		 System.out.println((char) i);
		//char c =255;
		int ii=220;
		//System.out.println(c);
		System.out.println((char) ii);


	}

}
