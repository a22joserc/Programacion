package unidad2;

import java.util.*;

public class Ejercicio6 {
	public enum Lenguaje {Java,C,Cs,PHP,Python};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Lenguaje len1=Lenguaje.Java;
		System.out.println("El lenguaje escogido ahora es " + len1);
		System.out.println("Los lenguajes escogidos son: ");
		Colores color = Colores.Amarillo;
		System.out.println("El color es: " + color);
		for(Lenguaje l: Lenguaje.values()) {
			System.out.println(l);
		}*/
		// String p1=Lenguaje.Java.toString();
		/*ArrayList<String> miLista = new ArrayList<String>();
		String s1="Juana";
		String s2="Mi hermana";
		miLista.add(s1);
		miLista.add(s2);
		System.out.println(miLista);
		for(String s: miLista) {
			System.out.println(s);
		}
		miLista.remove(s1);
		System.out.println(miLista);*/
		
		
	}

}
