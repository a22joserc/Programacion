package unidad2;

public enum Colores {Rojo,Azul,Amarillo}
