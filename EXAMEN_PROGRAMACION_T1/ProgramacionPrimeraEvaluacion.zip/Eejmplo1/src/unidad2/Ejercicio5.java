package unidad2;

public class Ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pag1="http//JavaSRC.wordpress.com";
		String pag2="\"http//JavaSRC.wordpress.com\"";
		System.out.println("Pagina:\t\t" + pag1);
		System.out.println("Pagina:" + pag2);
	}

}
