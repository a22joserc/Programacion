package unidad2;

import java.util.Scanner;

public class AreaCuadrado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lado, area;
		System.out.println("Introduzca el lado del cuadrado en m");
		Scanner sc = new Scanner(System.in);
		lado = sc.nextInt();
		sc.close();
		area=lado*lado;
		System.out.println("El area del cuadrado de lado " + lado + " m, es igual a " + area + " m2.");
	}

}
