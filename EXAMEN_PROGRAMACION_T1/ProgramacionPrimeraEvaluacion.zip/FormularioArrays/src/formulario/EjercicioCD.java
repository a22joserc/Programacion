package formulario;

public class EjercicioCD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {45,23,18,52,68,1};
		/*int [] array = new int[args.length];
		for (int i=0;i<args.length;i++){
			array[i] = Integer.parseInt(args[i]);
		}*/
		sortArray(array);
		//imprimirArray(array);

	}
	
	
	public static void sortArray(int[] array){
		for (int i=0;i<array.length-1;i++){
			imprimirArray(array);
			System.out.println("");
			for(int j=0;j<array.length-1-i;j++){
				if(array[j]>array[j+1]){
					int temp;
					temp=array[j+1];
					array[j+1]=array[j];
					array[j]=temp;
				}	
			}
		}
	}
	
	public static void imprimirArray(int[] array) {
		for (int num: array) {
			System.out.print(num + "\t");
		}
	}

}
