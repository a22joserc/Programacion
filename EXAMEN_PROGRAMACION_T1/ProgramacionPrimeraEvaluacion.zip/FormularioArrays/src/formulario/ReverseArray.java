package formulario;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {1, 2, 3, 4, 5};
		imprimirArray1D(array);
		//int[] reverseArray = new int[array.length];
		/*for (int i=0, j=array.length-1; i<reverseArray.length && j> -1; i++, j--) {
			reverseArray[i]= array[j];
		}*/
		
		/*for (int i=0; i<reverseArray.length; i++) {
			reverseArray[i]= array[array.length-1-i];
		}
		imprimirArray1D(array);
		imprimirArray1D(reverseArray);*/
		for (int i=0; i<array.length; i++) {
			int temp = array[i];
			System.out.println("Var puente: " + temp);
			System.out.println(array[array.length-1-i]);
			array[i]= array[array.length-1-i];
			array[array.length-1-i] = temp;
		}
		imprimirArray1D(array);

	}
	public static void imprimirArray1D(int[] array) {
		for (int num:array) {
			System.out.print(num + "\t");
		}
		System.out.println("");
	}
}
