package formulario;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array={8, 3, 5, 7, 2, 4};
		int range = range(array);
		System.out.println(range);

	}
	
	public static int range(int[] array) {
		int min=array[0];
		int max=array[0];
		int range;
		for (int i=0; i<array.length; i++) {
			if(array[i]>max) {
				max = array[i];
			}
			else if(array[i]<min) {
				min = array[i];
			}
		}
		range = max - min + 1;
		return range;
	}

}
