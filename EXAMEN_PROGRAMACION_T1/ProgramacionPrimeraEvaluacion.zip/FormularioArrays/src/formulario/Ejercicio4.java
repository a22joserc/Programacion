package formulario;

public class Ejercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isSorted(new double[]{16.1, 12.3, 22.2, 14.4}));
		System.out.println(isSorted(new double[]{1.5, 4.3, 7.0, 19.5, 25.1, 46.2}));
		System.out.println(isSorted(new double[]{1.5}));
		System.out.println(isSorted(new double[]{1.5,1.5}));

	}
	
	public static boolean isSorted(double[] array) {
		boolean sorted = true;
		for (int i=0; i<array.length-1; i++) {
			if (array[i+1] < array[i]) {
				sorted = false;
			}
		}
		return sorted;
	}

}
