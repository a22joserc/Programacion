package formulario;

public class Ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {3, 25, 18, 8, 5};
		for (int i=0; i<array.length; i++) {
			int temp = array[i];
			int min = array[i];
			int pos_min = i;
			for (int j=0+i; j<array.length; j++) {
				if (array[j]<min) {
					pos_min = j;
					min = array[j];
				}
				array[i] = min;
				array[pos_min] = temp;
			}
		}
		
		for (int num:array) {
			System.out.println(num);
		}
		

	}
	
	/*public static int kthLargest(int num, int[] array) {
		
	}*/
	
	/*public static int[] sortArray(int[] array) {
		int[] sortedArray = new int[array.length];
		for (int i=0; i<sortedArray.length; i++) {
			
		}
		return sortedArray;
	}*/

}
