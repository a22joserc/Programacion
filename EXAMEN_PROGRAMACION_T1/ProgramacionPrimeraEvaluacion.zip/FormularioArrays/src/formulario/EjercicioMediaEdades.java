package formulario;

public class EjercicioMediaEdades {
	
	public static void main(String[] args) {
		
				
		int[] edades = new int[args.length/2];
		String[] nombres = new String[args.length/2];
		// Rellenamos los arrays
		int j=0;
		for (int i=1; i <args.length; i+=2) {
			edades[j]=Integer.parseInt(args[i]);
			j++;
		}
		int q=0;
		for (int i=0; i <args.length; i+=2) {
			nombres[q]=args[i];
			q++;
		}
		imprimirEdades(edades);
		imprimirNombres(nombres);
		System.out.println("Edad media: " + edadMedia(edades));
	}
	
	public static void imprimirEdades(int[] array) {
		for (int edad: array) {
			System.out.print(edad + "\t");
		}
		System.out.println("");
	}
	
	public static void imprimirNombres(String[] array) {
		for (String nombre: array) {
			System.out.print(nombre + "\t");
		}
		System.out.println("");
	}
	
	public static double edadMedia(int[] array) {
		int suma = 0;
		double edadMedia;
		for (int i=0; i<array.length; i++) {
			suma += array[i];
		}
		edadMedia = (double)suma/array.length;
		return edadMedia;
		
	}

}
