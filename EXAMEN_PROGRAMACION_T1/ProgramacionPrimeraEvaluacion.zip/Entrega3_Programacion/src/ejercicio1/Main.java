package ejercicio1;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// Pedimos párametros al usuario
		/*Scanner sc = new Scanner(System.in);
		System.out.println("**************** EMPRESA *****************");
		System.out.println("Introduzca el CIF de la empresa");
		String cif = sc.nextLine();
		System.out.println("Introduzca el nombre de la empresa");
		String nomEmpresa = sc.nextLine();
		System.out.println("Introduzca la dirección de la empresa");
		String dirEmpresa = sc.nextLine();
		System.out.println("Introduzca el número de trabajadores de la empresa");
		int trabEmpresa = sc.nextInt();
		sc.nextLine();
		System.out.println("**************** TRABAJADOR *****************");
		System.out.println("Introduzca el DNI del trabajor");
		String dni = sc.nextLine();
		System.out.println("Introduzca el nombre del trabajador");
		String nomTrabajador = sc.nextLine();
		System.out.println("Introduzca los apellidos del trabajador");
		String apellTrabajador = sc.nextLine();
		System.out.println("Introduzca el lugar de nacimiento del trabajador");
		String lugTrabajador = sc.nextLine();
		System.out.println("Introduzca la edad del trabajador");
		int edadTrabajador = sc.nextInt();
		sc.close();
		// Instanciamos Empresa
		Empresa e1 = new Empresa(cif,nomEmpresa,dirEmpresa,trabEmpresa);
		System.out.println(e1.toString());
		// Instanciamos Trabajador
		Trabajador t1 = new Trabajador(e1,dni,nomTrabajador,apellTrabajador,edadTrabajador,lugTrabajador);
		System.out.println(t1.toString());*/
		
		/*String cadena = "45666783L:Juan:Lopez:45:Ourense|A80192727:Los hermanos S.L.:Calle Principal 5, Lugo|22";
		Scanner sc = new Scanner(cadena);
		sc.useDelimiter("\\|");
		String cadena1 = sc.next();
		//System.out.println(cadena1);
		Scanner sc1 = new Scanner(cadena1);
		sc1.useDelimiter(":");
		String dni = sc1.next();
		String nombre = sc1.next();
		String apellidos = sc1.next();
		int edad = sc1.nextInt();
		String lugar = sc1.next();
		String cadena2 = sc.next();
		//System.out.println(cadena2);
		Scanner sc2 = new Scanner(cadena2);
		sc2.useDelimiter(":");
		String cif = sc2.next();
		String nomEmpresa = sc2.next();
		String direccion = sc2.next();
		int empleados = sc.nextInt();
		// System.out.println(cadena3);
		
		Empresa e2 = new Empresa(cif,nomEmpresa,direccion,empleados);
		System.out.println(e2.toString());
		Trabajador t2 = new Trabajador(e2,dni,nombre,apellidos,edad,lugar);
		System.out.println(t2.toString());*/
		
		//String dni = "45666783L";
		/*String dni;
		int contLetra, contDigito;
		Scanner sc = new Scanner(System.in);
		do {
			contLetra=0;
			contDigito=0;
			System.out.println("Introduzca su DNI: ");
			dni = sc.nextLine();
			for (int i=0; i<dni.length(); i++) {
				if ((dni.charAt(i)>='a' && dni.charAt(i)<='z') || (dni.charAt(i) >='A' && dni.charAt(i) <='Z')) {
					contLetra++;
				}
				if (dni.charAt(i) >='0' && dni.charAt(i) <='9') {
					contDigito++;
				}
			}
			System.out.println("Digitos = " + contDigito);
			System.out.println("Letras = " + contLetra);
		}while(!(contDigito == 8 && contLetra == 1));
		sc.close();
		System.out.println("Validación realizada! DNI correcto!");*/
		
		/*boolean flag = true;
		contLetra=0;
		contDigito=0;
		while(flag) {
			System.out.println("Introduzca su DNI: ");
			dni = sc.nextLine();
			for (int i=0; i<dni.length(); i++) {
				ch = dni.charAt(i);
				if ((ch>='a' && ch<='z') || (ch>='A' && ch <='Z')) {
					contLetra++;
				}
				if (ch>='0' && ch<='9') {
					contDigito++;
				}
			}
			if (contDigito == 8 && contLetra == 1) {
				flag = false;
			}
			else {
				contLetra=0;
				contDigito=0;
			}
		}
		System.out.println("Digitos = " + contDigito);
		System.out.println("Letras = " + contLetra);*/
		
		
		/*String dni;
		int contLetra, contDigito;
		Scanner sc = new Scanner(System.in);
		do {
			contLetra=0;
			contDigito=0;
			System.out.println("Introduzca su DNI: ");
			dni = sc.nextLine();
			contLetra = obtenerLetrasDNI(dni);
			contDigito = obtenerDigitosDNI(dni);
			System.out.println("Digitos = " + contDigito);
			System.out.println("Letras = " + contLetra);
		}while(!(contDigito == 8 && contLetra == 1));
		sc.close();
		System.out.println("Validación realizada! DNI correcto!");*/
		
		
		String dni;
		boolean validar;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Introduzca su DNI: ");
			dni = sc.nextLine();
			// validar = validarDNI(dni);
			validar = validarDNIV2(dni);
			//System.out.println(validar);
		}while(!validar);
		sc.close();
		System.out.println("Validación realizada! DNI correcto!");
		
	}
	
	private static int obtenerLetrasDNI(String dni) {
		int contLetra = 0;
		for (int i=0; i<dni.length(); i++) {
			if ((dni.charAt(i)>='a' && dni.charAt(i)<='z') || (dni.charAt(i) >='A' && dni.charAt(i) <='Z')) {
				contLetra++;
			}
		}
		return contLetra;
	}
	
	private static int obtenerDigitosDNI(String dni) {
		int contDigito = 0;
		for (int i=0; i<dni.length(); i++) {
			if (dni.charAt(i) >='0' && dni.charAt(i) <='9') {
				contDigito++;
			}
		}
		return contDigito;
	}
	
	private static boolean validarDNI(String dni) {
		boolean validar;
		int contLetra = 0;
		int contDigito = 0;
		for (int i=0; i<dni.length(); i++) {
			if ((dni.charAt(i)>='a' && dni.charAt(i)<='z') || (dni.charAt(i) >='A' && dni.charAt(i) <='Z')) {
				contLetra++;
			}
			if (dni.charAt(i) >='0' && dni.charAt(i) <='9') {
				contDigito++;
			}
		}
		if (contDigito == 8 && contLetra == 1) {
			validar = true;
		}
		else {
			validar = false;
		}
		return validar;
	}

	
	private static boolean validarDNIV2(String dni) {
		boolean validar;
		int contLetra = obtenerLetrasDNI(dni);
		int contDigito = obtenerDigitosDNI(dni);
		if (contDigito == 8 && contLetra == 1) {
			validar = true;
		}
		else {
			validar = false;
		}
		return validar;
	}

}
