package ejercicio1;

public class Trabajador {
	
	// Variables de clase
	private Empresa empresa;
	private String dni;
	private String nombre;
	private String apellidos;
	private int edad;
	private String lugarNac;
	
	// Constructor por defecto
	
	public Trabajador() {
		empresa = null;
		dni = "12345678X";
		nombre = "Nombre Empleado";
		apellidos = "Apellidos Empleado";
		edad = 0;
		lugarNac = "Lugar Nacimiento Empleado";
	}
	
	// Constructor con paso de parámetros
	
	public Trabajador(Empresa empresa, String dni, String nombre, String apellidos, int edad, String lugarNac) {
		this.empresa = empresa;
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
		this.lugarNac = lugarNac;
	}
	
	// SETTERS
	
	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}
	
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void setLugarNac(String lugarNac) {
		this.lugarNac = lugarNac;
	}
	
	// GETTERS
	
	public Empresa getEmpresa() {
		return empresa;
	}
	
	public String getDni() {
		return dni;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public int getEdad() {
		return edad;
	}
	
	public String getLugarNac() {
		return lugarNac;
	}
	
	@Override
	public String toString() {
		return "***************************\nEmpresa : " + this.empresa.getNombre() + ";\nDNI: " + this.getDni() + ";\nNombre: " + this.getNombre() + ";\nApellidos: " + this.getApellidos() + ";\nEdad: " + this.getEdad() +"\n***************************";
	}
}
