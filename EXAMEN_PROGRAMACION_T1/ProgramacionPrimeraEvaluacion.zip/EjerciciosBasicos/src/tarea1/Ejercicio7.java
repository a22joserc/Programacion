package tarea1;

public class Ejercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("A \"quoted\" String is\n");
		System.out.print("\'much\' better if you learn\n");
		System.out.print("the rules of \"escape sequences.\"\n");
		System.out.print("Also, \"\" represents an empty String.\n");
		System.out.print("Don't forget: use \\\" instead of \" !\n");
		System.out.print("\'\' is not the same as \"");
	}

}
