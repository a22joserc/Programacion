package ej_for;

public class Ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0; i<128; i++) {
			System.out.println("Decimal: " + i + ", Binario: " + Integer.toBinaryString(i) + ", Hexadecimal: " + Integer.toHexString(i) + ", Octal: " + Integer.toOctalString(i));
		}

	}

}
