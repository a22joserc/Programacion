package ej_for;

public class Ejercicio14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 11;
		for (int i=0; i<3; i++) {
			for (int j=num; j<num+3; j++) {
				System.out.println(j);
			}
			num +=10;
		}

	}

}
