package ej_for;

public class Ejercicio15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=2; i<5; i++) {
			System.out.println("Tabla de multiplicar del número " + i);
			for (int j=1; j<11; j++) {
				System.out.println(i + " x " + j + " = " + (i*j));
			}
		}

	}

}
