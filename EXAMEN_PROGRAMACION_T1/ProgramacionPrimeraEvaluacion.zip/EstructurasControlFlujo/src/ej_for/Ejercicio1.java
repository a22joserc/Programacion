package ej_for;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0; i<101; i++) {
			System.out.println(i);
		}

	}

}
