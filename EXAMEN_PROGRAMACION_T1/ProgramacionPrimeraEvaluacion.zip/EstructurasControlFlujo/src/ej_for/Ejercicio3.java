package ej_for;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int suma = 0;
		for(int i=1; i<101; i++) {
			// suma = suma + i;
			suma += i;
		}
		System.out.println("La suma de los números del 1 al 100 es: " + suma);

	}

}
