package constructores;

public class B {
	private int y;
	
	B(){
		y=5;
	}
	
	B(int y){
		this.y=y;
	}
	
	public int getY() {
		return y;
	}
	

}
