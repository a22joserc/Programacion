package string;

public class DemoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String str1= new String("hola");
		String str2= "Adios";
		String str3=new String(str1);
		String str4=str1;

		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str4);*/
		
		/*String s1 = new String("hola");
		String s2 = new String("hola");
		if(s1==s2)
			System.out.println("s1 y s2 referencian al mismo objeto");
		else
			System.out.println("s1 y s2 NO referencian al mismo objeto");
		if(s1.equals(s2))
			System.out.println("s1 y s2 contien el mismo texto");
		else
			System.out.println("s1 y s2 NO contienen el mismo texto");*/
		
		/*String s1 = "hola";
		String s2 = "hola";
		if(s1==s2)
			System.out.println("s1 y s2 referencian al mismo objeto");
		else
			System.out.println("s1 y s2 NO referencian al mismo objeto");
		if(s1.equals(s2))
			System.out.println("s1 y s2 contien el mismo texto");
		else
			System.out.println("s1 y s2 NO contienen el mismo texto");*/
		
		String str1= " ho la ";
		System.out.println(str1+"adios");
		System.out.println(str1.trim()+"adios");
		System.out.println(str1+"adios"); 

	}

}
