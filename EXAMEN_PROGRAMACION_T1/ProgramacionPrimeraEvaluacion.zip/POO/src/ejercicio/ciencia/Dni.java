package ejercicio.ciencia;

public class Dni {
	char dni_letra;
	int dni_num;

}
