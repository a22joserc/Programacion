package poo;

public class Coche2 {
	String matricula;
	Rueda rueda_DD, rueda_DI, rueda_TI, rueda_TD;

}
