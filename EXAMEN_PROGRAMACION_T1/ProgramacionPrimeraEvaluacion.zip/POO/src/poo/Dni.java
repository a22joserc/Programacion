package poo;

public class Dni {
	char letra_dni;
	int num_dni;

}
