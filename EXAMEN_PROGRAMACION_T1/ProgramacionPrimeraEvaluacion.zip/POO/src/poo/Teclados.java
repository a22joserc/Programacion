package poo;

public enum Teclados {Americano, Español, Ruso, Italiano}
