package juegoPokemon;

public class EntrenadorPokemon {
	// Variables de clase
	private String nombre;
	private Pokemon[] equipo;
	
	public EntrenadorPokemon() {
		nombre = "Entrenador Pokemon";
		equipo = new Pokemon[5];
	}
	
	public EntrenadorPokemon(String nombre, Pokemon[] equipo) {
		this.nombre = nombre;
		this.equipo = equipo;
	}
	
	public EntrenadorPokemon(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public Pokemon[] getEquipo() {
		return this.equipo;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	/*public void setEquipo(Pokemon[] equipo) {
		this.equipo = equipo;
	}*/
	
	public void crearEquipo() {
		this.equipo = new Pokemon[5];
	}
	
	public void agregarPokemon(Pokemon pokemon, int pos) {
		this.equipo[pos] = pokemon;
	}
	
	public void agregarPokemoFusion(String nombre) {
		for (int i=0; i<this.equipo.length; i++) {
			if (this.equipo[i].getNombre().equals(nombre)) {
				this.equipo[i].agregarPokemonFusion(this.equipo[i]);
			}
		}
		
	}
	
	public void eliminarPokemon(int pos) {
		this.equipo[pos] = null;
	}
	
	public void eliminarPokemon(String nombre) {
		for (int i=0; i<this.equipo.length; i++) {
			if (this.equipo[i] != null && this.equipo[i].getNombre().equals(nombre)) {
				this.equipo[i]=null;
			}
		}
	}
	
	public void mostrarEquipo() {
		System.out.println("******************************************************************************************************");
		System.out.println("                                        INFORMACIÓN EQUIPO                                            ");
		System.out.println("******************************************************************************************************");
		System.out.println("Entrenador: " + this.getNombre());
		System.out.println("Componentes del equipo: ");
		for (int i=0; i<this.equipo.length; i++) {
			if (this.equipo[i] == null) {
				System.out.println("Pokemon #" + (i+1) + " : " + this.equipo[i]);
			}
			else {
				System.out.println("Pokemon #" + (i+1) + " : " + this.equipo[i].toString());
			}

		}
		System.out.println("******************************************************************************************************");
	}
	
	
	/*public int[] contarTipoPokemon() {
		// Devuelve un array de longitud 4
		// Posición 0: Número de Squirtles
		// Posición 1: Número de Charmanders
		// Posición 2: Número de Bulbasurs
		// Posición 3: Número de Pikachus
		int[] contTipoPokemon = new int[tiposPokemon.values().length];
		int j=0;
		for (tiposPokemon pokemon: tiposPokemon.values()) {
			for (int i=0; i<this.equipo.length; i++) {
				if (this.equipo[i].getTipo() == pokemon) {
					contTipoPokemon[j] += 1;
				}
			}
			j++;
		}
		return contTipoPokemon;
	}*/
	
	
	public int[] contarTipoPokemon() {
		// Devuelve un array de longitud 4
		// Posición 0: Número de Squirtles
		// Posición 1: Número de Charmanders
		// Posición 2: Número de Bulbasurs
		// Posición 3: Número de Pikachus
		int[] contTipoPokemon = new int[tiposPokemon.values().length];
		for (int j=0; j < tiposPokemon.values().length; j++) {
			for (int i=0; i<this.equipo.length; i++) {
				if (this.equipo[i].getTipo() == tiposPokemon.values()[j]) {
					contTipoPokemon[j] += 1;
				}
			}
		}
		return contTipoPokemon;
	}

	
	public static int[][] getArray2DEntrenadorTipoPokemon(EntrenadorPokemon[] entrenadores) {
		int[][] array = new int[entrenadores.length][];
		for (int i=0; i<array.length; i++) {
			array[i] = entrenadores[i].contarTipoPokemon();
		}
		imprimirEntrenadorTipoPokemon(array, entrenadores);
		return array;
	}
	
	
	private static void imprimirEntrenadorTipoPokemon(int[][] array, EntrenadorPokemon[] entrenadores) {
		for (int i=0; i<array.length; i++) {
			if (i == 0) {
				for(tiposPokemon pokemon: tiposPokemon.values()) {
					System.out.print("\t" + pokemon.toString());
				}
				System.out.println("");
			}
			for (int j=0; j<array[i].length; j++) {
				if (j==0) {
					System.out.print(entrenadores[i].getNombre() + "\t" + array[i][j] + "\t\t");
				}
				else {
					System.out.print(array[i][j] + "\t\t");
				}
			}
			System.out.println("");
		}
	}
}
