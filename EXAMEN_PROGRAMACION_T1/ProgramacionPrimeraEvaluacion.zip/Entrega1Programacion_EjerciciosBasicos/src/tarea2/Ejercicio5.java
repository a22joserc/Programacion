package tarea2;

public class Ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("   -------");
		// System.out.println("   _______");
		System.out.println("  /       \\");
		System.out.println(" /         \\");
		System.out.println(" _\"_'_\"_'_\"_");
		System.out.println(" \\         /");
		System.out.println("  \\_______/");
	}

}
