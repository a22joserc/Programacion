package ejmplosBasicosRecursividad;

public class DemoRecursividad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Recursividad recursividad = new Recursividad();
		System.out.println(recursividad.sumarNumeros(4));
		recursividad.imprimirNumerosDescendentes(5);
		System.out.println(recursividad.multiplicar(7,5));
		System.out.println(recursividad.factorial(5));

	}

}
