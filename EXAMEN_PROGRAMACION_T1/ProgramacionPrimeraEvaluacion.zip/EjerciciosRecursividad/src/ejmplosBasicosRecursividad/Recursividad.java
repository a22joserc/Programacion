package ejmplosBasicosRecursividad;

public class Recursividad {
	
	
	public int sumarNumeros(int num) {
		int suma;
		if (num == 1) {
			suma = 1;
		}
		else {
			suma = num + sumarNumeros(num-1);
		}
		return suma;	
	}
	
	public void imprimirNumerosDescendentes(int num) {
		if (num == 0) {
			System.out.println("");
		}
		else {
			System.out.print(num + " ");
			imprimirNumerosDescendentes(num-1);
		}
		
	}
	
	public int multiplicar(int a, int b) {
		int producto;
		if (b==1) {
			producto = a;
		}
		else {
			producto = a + multiplicar(a,b-1);
		}
		return producto;
	}
	
	public int factorial(int num) {
		int resultado;
		if(num==0) {
			resultado = 1;
		}
		else {
			resultado = num * factorial(num-1);
		}
		return resultado;
		
	}
	
	

}
