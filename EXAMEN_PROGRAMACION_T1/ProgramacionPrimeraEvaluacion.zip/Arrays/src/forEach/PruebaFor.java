package forEach;

public class PruebaFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = {2,4,7,1,5};
		int sum = 0;
		double media;
		for(int i=0; i<nums.length; i++) { // bucle for-each
			sum += nums[i]; // n ← cada elemento de la colección nums
		}
		media = (double)sum/nums.length;
		System.out.printf("La suma es: %d y media es: %.2f%n", sum, media);
	}

}
