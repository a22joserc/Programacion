package forEach;

public class PruebaForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int nums[] = { 2, 4, 7, 1, 5 };
		int sum = 0;
		double media;
		for(int n: nums) { // bucle for-each
			sum += n; // n ← cada elemento de la colección nums
		}
		media = (double)sum/nums.length;
		System.out.printf("La suma es: %d y media es: %.2f%n", sum, media);

	}

}
