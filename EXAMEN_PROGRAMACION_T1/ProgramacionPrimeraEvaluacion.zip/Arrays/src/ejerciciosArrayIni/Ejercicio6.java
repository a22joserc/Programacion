package ejerciciosArrayIni;
import java.util.Random;

public class Ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rdm = new Random();
		int[] diasMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		int[][][] arrayTresD = new int[12][][];
		for (int i=0; i<arrayTresD.length; i++) {
			arrayTresD[i] = new int[diasMes[i]][23];
		}
		// Iniciañozamos Array
		for (int i=0; i<arrayTresD.length; i++) {
			System.out.println("Mes: " + (i+1));
			for (int j=0; j<arrayTresD[i].length; j++) {
				System.out.println("\tDia: " + (j+1));
				for (int q=0; q<arrayTresD[i][j].length; q++) {
					System.out.println("\t\tHora: " + (q+1));
					arrayTresD[i][j][q] = rdm.nextInt(0,100);

				}
				
			}
		}
		
	}

}
