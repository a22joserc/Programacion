package ejemplos;

public class ejemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] sq = new int[100]; // creación array
		for(int i=0; i<sq.length; i++) { // bucle inicialización
			sq[i] = i*i;
		}
		for(int i=0; i<sq.length; i++) { // bucle impresión
			System.out.printf("%04d%c", sq[i], ((i+1)%10==0)?'\n':'\t');
		}

	}

}
