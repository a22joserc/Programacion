package tarea1;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N=1;
		System.out.println("N = " + N);
		N+=77; // Alternativa N=N+77;
		System.out.println("N + 77 = " + N);
		N-=3; // Alternativa N=N-3
		System.out.println("N - 3 = " + N);
		N*=2; // N=N*2
		System.out.println("N * 2 = " + N);
	}

}
