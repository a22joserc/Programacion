package demoPersona;

public class Persona {
	String nombre;
	int edad;

}
