package ejercicio.ciencia;

public class Cientifico {
	String nombre;
	String apellidos;
	Dni dni;
	float salario;
	Cientifico jefe;
	boolean es_jefe;

}
