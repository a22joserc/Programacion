package contornos;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N = 10;
		int fib = 0;
		for(int i=0; i<N; i++) {
			System.out.println((fib+i));
			
		}

	}

}
