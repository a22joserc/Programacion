package variable.referencia;

public class Coche {
	int pasajeros;
	int deposito;
	double kpl;

}
