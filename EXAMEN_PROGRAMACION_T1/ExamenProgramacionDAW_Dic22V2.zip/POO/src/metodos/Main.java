package metodos;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Coche coche = new Coche();
		coche.pasajeros = 5;
		coche.deposito = 100;
		coche.kpl = 5;
		System.out.println("La autonomia del coche es " + coche.calcularAutonomia());
		int km = 100;
		System.out.println("La gasolina necesaria para recorrer " + km + " km es de  " + coche.gasofaNecesaria(km) + " litros");*/
		System.out.println("************ BICICLETA 1 *********************");
		//Bicicleta b1 = new Bicicleta(); 
		// Bicicleta b1 = new Bicicleta(20.0); 
		// Bicicleta b1 = new Bicicleta(2); 
		Bicicleta b1 = new Bicicleta(20,2); 
		b1.imprimirEstado();
		// b1.vel=20;
		// b1.marcha=2;
		// b1.setVel(20);
		//b1.setMarcha(2);
		/*System.out.println("La marcha de la bicicleta es " + b1.getMarcha());
		System.out.println("La velocidad es " + b1.getVel());
		b1.acelerar(10);
		System.out.println("La velocidad es " + b1.getVel());
		b1.frenar(5);
		System.out.println("La velocidad es " + b1.getVel());
		b1.cambiarMarcha(4);
		System.out.println("************ ESTADO ***********************");
		b1.imprimirEstado();
		System.out.println("************ BICICLETA 2 *********************");
		Bicicleta b2 = new Bicicleta();
		// b2.vel=0;
		// b2.marcha=1;
		b2.setVel(0);
		b2.setMarcha(1);
		System.out.println("La marcha de la bicicleta es " + b2.getMarcha());
		b2.cambiarMarcha(6);
		System.out.println("La marcha de la bicicleta es " + b2.getMarcha());
		b2.acelerar(20);
		System.out.println("La velocidad es " + b2.getVel());
		b2.frenar(10);
		System.out.println("La velocidad es " + b2.getVel());
		System.out.println("************ ESTADO ***********************");
		b2.imprimirEstado();*/
	}

}
