package poo;

public class Teclado {
	long id;
	Teclados tipo;
	String color;
}
