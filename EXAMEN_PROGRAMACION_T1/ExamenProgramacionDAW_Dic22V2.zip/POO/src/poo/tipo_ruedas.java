package poo;

public enum tipo_ruedas {DD,DI,TD,TI}
