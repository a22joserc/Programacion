package poo;

public class Persona {
	String nombre;
	String apellidos;
	// String nombre_completo;
	int edad;
	Dni dni;
	Coche2 coche;
	
	/*public Persona(String nombre, String apellidos, int edad) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.nombre_completo=nombre + " " + apellidos;
		this.edad=edad;*/
		
	//}

}
