package poo;

public class Raton {
	long serial;
	int botones;

}
