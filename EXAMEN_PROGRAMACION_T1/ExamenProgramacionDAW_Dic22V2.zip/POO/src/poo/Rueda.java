package poo;

public class Rueda {
	int ano_compra;
	tipo_ruedas posicion;
	
	@Override
	public String toString() {
		return "INFO RUEDA - Posicion: " + posicion + "; Año compra" + ano_compra;
	}

}
