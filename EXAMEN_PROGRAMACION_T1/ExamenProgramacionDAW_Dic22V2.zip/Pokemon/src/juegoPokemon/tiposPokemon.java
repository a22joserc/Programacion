package juegoPokemon;

public enum tiposPokemon {Squirtle, Charmander, Bulbasaur, Pikachu}
