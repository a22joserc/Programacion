package juegoPokemon;
import java.util.Scanner;

public class DemoPokemon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);
		String menu;
		do {
			System.out.println("****************************** POKEMON 1.0 ****************************************");
			System.out.println("Seleccione lo que desee hacer");
			System.out.println("POKEMON: Prueba para comprobar las funcionalidades de la clase Pokemon");
			System.out.println("ENTRENADOR: Prueba para comprobar las funcionalidades de la clase EntrenadorPokemon");
			System.out.println("EQUIPOS: Prueba para imprimir la tabla Equipos/Entrenador vs TipoPokemon");
			String opcionMenu = sc.nextLine();
			switch (opcionMenu) {
				case "POKEMON":
					System.out.println("*********************** PRUEBA CLASE POKEMON ******************************");
					System.out.println("***************************************************************************");
					Pokemon pokemonPrueba = new Pokemon("pokemonPrueba");
					pruebasClasePokemon(pokemonPrueba);
					System.out.println("***************************************************************************");
					break;
				case "ENTRENADOR":
					System.out.println("********************** PRUEBA CLASE ENTRENADOR ****************************");
					System.out.println("***************************************************************************");
					EntrenadorPokemon entrenador = new EntrenadorPokemon("Ash Ketchun");
					pruebaClaseEntrenadorPokemon(entrenador);
					System.out.println("***************************************************************************");
					break;
				case "EQUIPOS":
					System.out.println("********************** PRUEBA EQUIPOS POKEMON *****************************");
					System.out.println("***************************************************************************");
					String[] nombresEntrenador = {"Ent1","Ent2","Ent3","Ent4","Ent5"};
					String[] nombresPokemon = {"PK1","PK2","PK3","PK4","PK5"};
					EntrenadorPokemon[] entrenadoresPokemon = new EntrenadorPokemon[nombresEntrenador.length];
					System.out.println("Rellenamos iterativamente con Pokemons los equipos de cada uno de los entrenadores: ");
					/*
					int j = 0;
					for(String nomEnt: nombresEntrenador) {
						EntrenadorPokemon ent = new EntrenadorPokemon(nomEnt);
						ent.crearEquipo();
						for (int i=0; i<ent.getEquipo().length; i++) {
							System.out.println("Introduciendo el Pokemon de nombre " + nombresPokemon[i] + "_" + nomEnt + " en el EQUIPO del entrenador " + ent.getNombre());
							ent.getEquipo()[i] = new Pokemon(nombresPokemon[i] + "_" + nomEnt);
						}
						entrenadoresPokemon[j] = ent;
						j++;
					}
					*/
					for (int i=0; i < entrenadoresPokemon.length; i++) {
						entrenadoresPokemon[i] = new EntrenadorPokemon(nombresEntrenador[i]);
						entrenadoresPokemon[i].crearEquipo();
						for (int j=0; j < entrenadoresPokemon[i].getEquipo().length; j++) {
							System.out.println("Introduciendo el Pokemon de nombre " + nombresPokemon[j] + "_" + nombresEntrenador[i] + " en el EQUIPO del entrenador " + entrenadoresPokemon[i].getNombre());
							// entrenadoresPokemon[i].getEquipo()[j] = new Pokemon(nombresPokemon[j] + "_" + nombresEntrenador[i]);
							entrenadoresPokemon[i].agregarPokemon(new Pokemon((nombresPokemon[j] + "_" + nombresEntrenador[i])), j);
						}
					}
					System.out.println("****************************************************************************");
					System.out.println("Generarmos el array e imprimimos la tabla de Entrenador/equipo vs TipoPokemon: ");
					System.out.println("****************************************************************************");
					int[][] datos = EntrenadorPokemon.getArray2DEntrenadorTipoPokemon(entrenadoresPokemon);
					System.out.println("****************************************************************************");
					break;
				default:
					System.out.println("ERROR! La opción elegida no se encuentra disponible en el juego!");
					break;
			}
			System.out.println("Escriba EXIT para salir del menú. Pulse cualquier tecla para permanecer en el mismo.");
			menu = sc.nextLine();
		}while(menu.equalsIgnoreCase("exit")==false);
		sc.close();	
		
	}
	
	
	public static void pruebasClasePokemon(Pokemon pokemon) {
		System.out.println("Estado inicial del Pokemon: ");
		pokemon.mostrarDatos();
		System.out.println("Reducción de vida del Pokemon en 20 unidades de vida: ");
		pokemon.reducirVida(20);
		System.out.println(pokemon.toString());
		System.out.println("Sanar totalmente al Pokemon: ");
		pokemon.sanarTotalmente();
		System.out.println(pokemon.toString());
		System.out.println("Reducción de vida del Pokemon en 30 unidades de vida: ");
		pokemon.reducirVida(30);
		System.out.println(pokemon.toString());
		System.out.println("Prueba tomarPoción con int (10 unidades de vida) ");
		pokemon.tomarPocion(10);
		System.out.println(pokemon.toString());
		System.out.println("tomarPoción con float:  (10% de la vida actual)");
		pokemon.tomarPocion(10f);
		System.out.println(pokemon.toString());
		System.out.println("Comprobamos que la vida máxima no pasa de 100 al añadir 20 unidades vida: ");
		pokemon.tomarPocion(20);
		System.out.println(pokemon.toString());
	}
	
	
	public static void pruebaClaseEntrenadorPokemon(EntrenadorPokemon entrenador) {
		System.out.println("Creamos un equipo con una capacidad máxima de 5 Pokemons ... ");
		entrenador.crearEquipo();
		System.out.println("Rellenamos de forma iterativa el equipo creado con 5 Pokemons: ");
		String[] nombresPokemon = {"PK1","PK2","PK3","PK4","PK5"};
		for (int i=0; i<entrenador.getEquipo().length; i++) {
			System.out.println("Introduciendo el Pokemon de nombre " + nombresPokemon[i] + " en el equipo del entrenador " + entrenador.getNombre());
			entrenador.getEquipo()[i] = new Pokemon(nombresPokemon[i]);
		}
		System.out.println("Mostramos la información del Equipo: ");
		entrenador.mostrarEquipo();
		System.out.println("Eliminamos Pokemon por nombre (en este caso PK1): ");
		entrenador.eliminarPokemon("PK1");
		entrenador.mostrarEquipo();
		System.out.println("Eliminamos Pokemon por posición (en este caso la posción 4): ");
		entrenador.eliminarPokemon(4);
		entrenador.mostrarEquipo();
		System.out.println("Agregamos Pokemon por posición (en este caso un null en la posción 3): ");
		entrenador.agregarPokemon(null, 3);
		entrenador.mostrarEquipo();
		System.out.println("Agregamos Pokemon por posición (en este caso creamos un nuevo pokemon de nombre PK6 y lo introducimos en la posición 4): ");
		Pokemon pokemon6 = new Pokemon("PK6");
		entrenador.agregarPokemon(pokemon6, 4);
		entrenador.mostrarEquipo();
		System.out.println("Agregamos Pokemon por posición (en este caso creamos un nuevo pokemon de nombre PK7 y lo introducimos en la posición 0): ");
		Pokemon pokemon7 = new Pokemon("PK7");
		entrenador.agregarPokemon(pokemon7, 0);
		entrenador.mostrarEquipo();
		System.out.println("Agregamos Pokemon por posición (en este caso creamos un nuevo pokemon de nombre PK8 y lo introducimos en la posición 3): ");
		Pokemon pokemon8 = new Pokemon("PK8");
		entrenador.agregarPokemon(pokemon8, 3);
		entrenador.mostrarEquipo();
	}
	
}
