package ejercicioRecursividadMultiplicar;

public class MainMultiplicar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multiplicacion m = new Multiplicacion();
		System.out.println(m.multiplicar(2,10));
	}

}
