package pruebaPOO;

public enum tipoRueda {DD, DI, TD, TI, RR}
