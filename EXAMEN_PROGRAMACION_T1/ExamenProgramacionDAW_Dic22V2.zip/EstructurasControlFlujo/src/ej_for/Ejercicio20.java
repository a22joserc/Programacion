package ej_for;

public class Ejercicio20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "";
		for (int i=0; i<10; i++) {
			str = str.concat("*");
			System.out.println(str);
		}
	}

}
