package ej_for;

public class Ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int prod = 1;
		for (int i=1; i<12; i++) {
			System.out.println(prod);
			prod = prod * 2;
		}
		
		for (int j=1; j<=1024; j*=2) {
			System.out.println(j);
		}

	}

}
