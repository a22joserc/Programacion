package ej_for;

public class Ejercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=50; i> - 1; i-=2) {
			System.out.print(i + " ");
		}
		System.out.println("");
		int j = 50;
		while(j > -1) {
			System.out.print(j + " ");
			j -= 2;
		}
		System.out.println("");
		int q = 50;
		do {
			System.out.print(q + " ");
			q -= 2;
		}while(q > -1);

	}

}
