package ej_for;

public class Ejercicio17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*int base = 9;
		int exp = 5;
		int pot = 1;
		for(int i=0; i<exp; i++) {
			pot=pot*base;	
		}
		System.out.println(pot);*/
		
		Potencia p = new Potencia();
		System.out.println(p.elevar(9,5));
	}

}
