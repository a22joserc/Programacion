package ej_while;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int i = 0;
		while(i < 11) {
			System.out.println(i + " es par!");
			i += 2;
		}*/
		
		int j = 0;
		do {
			System.out.println(j + " es par!");
			j += 2;
		}while(j<11);

	}

}
