package ej_while;

public class Ejercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*char c = 'a';
		int i = 0;
		while(i < 26) {
			System.out.println(c);
			c++;
			i++;
		}*/
		
		char c = 'a';
		while(c <= 'z') {
			System.out.println(c++);
		}

	}

}
