package pruebaPOO;

public enum tipoCoche {Diesel, Gasolina, Hibrido, Electrico}
