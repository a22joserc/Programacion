package juegoPokemon;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("********************** PRUEBA EQUIPOS POKEMON *****************************");
		System.out.println("***************************************************************************");
		String[] nombresEntrenador = {"Ent1","Ent2","Ent3","Ent4","Ent5"};
		String[] nombresPokemon = {"PK1","PK2","PK3","PK4","PK5"};
		EntrenadorPokemon[] entrenadoresPokemon = new EntrenadorPokemon[nombresEntrenador.length];
		System.out.println("Rellenamos iterativamente con Pokemons los equipos de cada uno de los entrenadores: ");
		for (int i=0; i < entrenadoresPokemon.length; i++) {
			entrenadoresPokemon[i] = new EntrenadorPokemon(nombresEntrenador[i]);
			entrenadoresPokemon[i].crearEquipo();
			for (int j=0; j < entrenadoresPokemon[i].getEquipo().length; j++) {
				System.out.println("Introduciendo el Pokemon de nombre " + nombresPokemon[j] + "_" + nombresEntrenador[i] + " en el EQUIPO del entrenador " + entrenadoresPokemon[i].getNombre());
				entrenadoresPokemon[i].agregarPokemon(new Pokemon((nombresPokemon[j] + "_" + nombresEntrenador[i])), j);
			}
		}
		int[][] tabla = obtenerTabla(entrenadoresPokemon);
	}
	
	
	public static int[][] obtenerTabla(EntrenadorPokemon[] entrenadores){
		// Creamos tabla
		int[][] tabla = new int[entrenadores.length][tiposPokemon.values().length];
		for (int i=0; i< tabla.length; i++) {
			for (int j=0; j< tabla[i].length; j++) {
				// int cont=0;
				for (int q = 0; q < entrenadores[i].getEquipo().length; q++) {
					if (entrenadores[i].getEquipo()[q].getTipo() == tiposPokemon.values()[j]) {
						// cont++;
						tabla[i][j]++;
					}
					//tabla[i][j] = cont;
				}
			}
		}
		// Imprimimos Tabla
		for (int i=0; i<tabla.length; i++) {
			if (i == 0) {
				for(tiposPokemon pokemon: tiposPokemon.values()) {
					System.out.print("\t" + pokemon.toString());
				}
				System.out.println("");
			}
			for (int j=0; j<tabla[i].length; j++) {
				if (j==0) {
					System.out.print(entrenadores[i].getNombre() + "\t" + tabla[i][j] + "\t\t");
				}
				else {
					System.out.print(tabla[i][j] + "\t\t");
				}
			}
			System.out.println("");
		}
		return tabla;
		
	}

}
