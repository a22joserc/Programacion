package juegoPokemon;
import java.util.Random;

public class Pokemon {
	
	// Instancias de clase
	
	private String nombre;
	private tiposPokemon tipo;
	private int vida;
	private final static int VIDA_MAXIMA = 100;
	private int nivel;
	private Pokemon pokemonFusion;
	
	// Constructor por defecto
	
	public Pokemon(){
		nombre = "Pokemon Generirco";
		this.setTipo();
		vida = VIDA_MAXIMA;
		nivel = 1;
		pokemonFusion = null;
	}
	
	// Constructor por paso de Parámetros
	
	public Pokemon(String nombre){
		this.nombre = nombre;
		this.setTipo();
		this.vida = VIDA_MAXIMA;
		this.nivel = 1;
		this.pokemonFusion = null;
	}
	
	// GETTERS
	
	public String getNombre() {
		return this.nombre;
	}
	
	public int getNivel() {
		return nivel;
	}
	
	public tiposPokemon getTipo() {
		return tipo;
	}
	
	public int getVida() {
		return vida;
	}
	
	public Pokemon getPokemonFusion() {
		return this.pokemonFusion;
	}
	
	// SETTERS
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	public void agregarPokemonFusion(Pokemon pokemon) {
		this.pokemonFusion = pokemon;
	}
	
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
	
	public void setTipo() {
		Random rdm = new Random();
		int num = rdm.nextInt(1,11);
		if (num>=1 && num<=3) {
			this.tipo = tiposPokemon.Bulbasaur;
		}
		else if (num>=4 && num<=6) {
			this.tipo = tiposPokemon.Charmander;
		}
		else if (num>=7 && num<=9) {
			this.tipo = tiposPokemon.Squirtle;
		}
		else {
			this.tipo = tiposPokemon.Pikachu;
		}
	}
	
	// MÉTODOS
	
	public void sanarTotalmente() {
		this.vida = VIDA_MAXIMA;
	}
	
	public void tomarPocion(int vida) {
		if (this.vida + vida > 100) {
			this.vida = 100;
		}
		else{
			this.vida += vida;
		}
	}
	
	public void tomarPocion(float porcentaje) {
		int incrementoVida = (int) (this.vida * porcentaje/100);
		if (this.vida + incrementoVida > 100) {
			this.vida = 100;
		}
		else {
			this.vida += incrementoVida;
		}
	}
	
	public void reducirVida(int cantidad){
		this.vida -= cantidad;
	}
	
	public tiposPokemon generarTipoPokemon() {
		Random rdm = new Random();
		int num = rdm.nextInt(1,11);
		if (num>=1 && num<=3) {
			return tiposPokemon.Bulbasaur;
		}
		else if (num>=4 && num<=6) {
			return tiposPokemon.Charmander;
		}
		else if (num>=7 && num<=9) {
			return tiposPokemon.Squirtle;
		}
		return tiposPokemon.Pikachu;
	}
	
	public void mostrarDatos() {
		System.out.println("****** INFO POKEMON *******");
		System.out.println("NOMBRE: " + this.getNombre());
		System.out.println("TIPO: " + this.getTipo());
		System.out.println("VIDA: " + this.getVida());
		System.out.println("NIVEL:" + this.getNivel());
		System.out.println("***************************");
	}
	
	@Override
	public String toString() {
		return "NOMBRE: " + this.getNombre() + "; TIPO: " + this.getTipo() + "; VIDA: " + this.getVida() + "; NIVEL: " + this.getNivel();
	}

}
